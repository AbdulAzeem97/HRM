<footer class="main-footer">
    <div class="container-fluid">
        <p>&copy; <?php echo e($generalSetting->footer ?? "no title"); ?> || <?php echo e(__('Developed by')); ?>

            <a href="<?php echo e($generalSetting->footer_link); ?>" class="external"> <?php echo e($generalSetting->developed_by); ?> </a> || Version - 1.2.1 <!-- config('app.version') }} -->
        </p>
    </div>
</footer>
<?php /**PATH D:\laragon\www\peopleprosaas\resources\views/landlord/super-admin/partials/footer.blade.php ENDPATH**/ ?>