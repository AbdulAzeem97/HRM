<?php


// it('performs sums', function () {
//     $result = sum(1, 2);

//     // $this->assertEquals($sum,3);
//     expect($result)->toBe(3);
// });

// it('check trait', function () {
//     $result = test();

//     expect($result)->toBe(95);
// });
