<?php

return
    [
        'product_mode' => env('PRODUCT_MODE'),
        'version' => env('VERSION'),
        'bug_no' => env('BUG_NO'),
        'demo_url' => 'https://peopleprohrmsaas.com/api',
    ];
?>
