<?php

return [

	'd-m-Y' => 'dd-mm-yyyy',
	'Y-m-d' => 'yyyy-mm-dd',

	'm/d/Y' => 'mm/dd/yyyy',
	'Y/m/d' => 'yyyy/mm/dd',

	'Y-M-d' => 'yyyy-M-d',
	'M-d-Y' => 'M-dd-yyyy',
	'd-M-Y' => 'dd-M-yyyy',


];