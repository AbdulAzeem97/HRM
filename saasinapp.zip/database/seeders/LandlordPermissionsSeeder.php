<?php

namespace Database\Seeders;

use App\Http\traits\PermissionHandleTrait;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LandlordPermissionsSeeder extends Seeder
{
    use PermissionHandleTrait;
    // php artisan db:seed --class=LandlordPermissionsSeeder

    public function run()
    {
		DB::table('permissions')->delete();

        $permissions = $this->getAllPermissions();

        DB::table('permissions')->insert($permissions);
    }

}
